public class Point {
   final float x;
   final float y;

   public Point(float x,float y){
      this.x = x;
      this.y = y;
   }
}
