public abstract class GeoFig {
   public abstract boolean intersect(LineSegment line);
}
